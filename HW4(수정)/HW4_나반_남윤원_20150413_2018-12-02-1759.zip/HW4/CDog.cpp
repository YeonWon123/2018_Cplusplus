#include <iostream>
#include "CDog.h"
#include <string>
using namespace std;

CDog::CDog()
	:CPet()
{
	m_strBreed = NULL;
}

CDog::CDog(const char *strName, const char *strBreed, int nActive)
	:CPet(strName, strBreed)
{
	m_nActive = nActive;
}

CDog::CDog(const CDog &ob)
	:CPet(ob)
{
	int length = strlen(ob.m_strBreed) + 1;
	m_strBreed = new char[length];
	strcpy(m_strBreed, ob.m_strBreed);
}

char* CDog::getBreed(void) const
{
	return m_strBreed;
}

void CDog::setBreed(const char *br)
{
	int length = strlen(br)+1;
	if(m_strBreed !=NULL)
	   delete [] m_strBreed;
	m_strBreed = new char[length];
	strcpy(m_strBreed, br);
}

void CDog::MakeSound(void)
{ 
	cout << "�۸�" << endl;
	PlaySound(TEXT("Dog-barking-noise.wav"), NULL, SND_SYNC);
}

void CDog::ShowHappyFace(char* strName)
{
	cout << "������ ������" << endl;

	string address;
	if (strcmp(strName,"�ȶ���") == 0)
		address = "dog1.jpg";
	else if (strcmp(strName, "������") == 0)
		address = "dog2.jpg";
	else if (strcmp(strName, "ĥĥ��") == 0)
		address = "dog3.jpg";
	else
	{
		cout << "����! �����ڿ��� �����ϼ���!";
		return;
	}

	Mat image;
	image = imread(address);
	namedWindow("Pets", WINDOW_AUTOSIZE);
	imshow("Pets", image);
	waitKey(10);
}

void CDog::ShowHappiness(char* strName)
{
	print();
	ShowHappyFace(strName);
	MakeSound();
}

void CDog::print(void)
{
	cout << endl;
	cout << "CDog Information" << endl;
	cout << "Name: " << m_strName << endl;
	cout << "m_strBreed: " << m_strBreed << endl;
	cout << "m_nActive: " << m_nActive << endl;
}

const CDog& CDog::operator =(const CDog& rightSide)
{
	if(this == &rightSide)
		return *this;
	
	CPet::operator=(rightSide);
	
	int length = strlen(rightSide.m_strBreed) + 1;
	if(m_strBreed !=NULL)
		delete [] m_strBreed;
	m_strBreed = new char[length];
	strcpy(m_strBreed, rightSide.m_strBreed);

	return *this;
}

int CDog::getActive(void)
{
	return m_nActive;
}

void CDog::setActive(int nActive)
{
	m_nActive = nActive;
}


CDog::~CDog()
{
	if(m_strBreed != NULL)
		delete [] m_strBreed;
}
