#include <iostream>
#include "CCat.h"

using namespace std;

CCat::CCat()
	:CPet()
{
	m_strBreed = NULL;
}

CCat::CCat(const char *strName, const char *strBreed, int nMaintenanceLevel)
	:CPet(strName, strBreed)
{
	m_nMaintenanceLevel = nMaintenanceLevel;
}

CCat::CCat(const CCat &ob)
	:CPet(ob)
{
	int length = strlen(ob.m_strBreed) + 1;
	m_strBreed = new char[length];
	strcpy(m_strBreed, ob.m_strBreed);
}

char* CCat::getBreed(void) const
{
	return m_strBreed;
}

void CCat::setBreed(const char *br)
{
	int length = strlen(br) + 1;
	if(m_strBreed !=NULL)
	   delete [] m_strBreed;
	m_strBreed = new char[length];
	strcpy(m_strBreed, br);
}

void CCat::MakeSound(void)
{ 
	cout << "�߿�" << endl;
	PlaySound(TEXT("Cat-barking-noise.wav"), NULL, SND_SYNC);
}


void CCat::ShowHappyFace(char* strName)
{
	cout << "������ �̼�" << endl;
	string address;
	if (strcmp(strName, "�����") == 0)
		address = "cat1.jpg";
	else if (strcmp(strName, "�ɳ���") == 0)
		address = "cat2.jpg";
	else
	{
		cout << "����! �����ڿ��� �����ϼ���!";
		return;
	}

	Mat image;
	image = imread(address);
	namedWindow("Pets", WINDOW_AUTOSIZE);
	imshow("Pets", image);
	waitKey(10);
}

void CCat::ShowHappiness(char* strName)
{
	print();
	ShowHappyFace(strName);
	MakeSound();
}

void CCat::print(void)
{
	cout << endl;
	cout << "CCat Information" << endl;
	cout << "Name: " << m_strName << endl;
	cout << "m_strBreed: " << m_strBreed << endl;
	cout << "m_nMaintenanceLevel: " << m_nMaintenanceLevel << endl;
}

const CCat& CCat::operator =(const CCat& rightSide)
{
	if(this == &rightSide)
		return *this;
	
	CPet::operator=(rightSide);
	
	int length = strlen(rightSide.m_strBreed);
	if(m_strBreed !=NULL)
		delete [] m_strBreed;
	m_strBreed = new char[length];
	strcpy(m_strBreed,rightSide.m_strBreed);

	return *this;
}

int CCat::getMaintenanceLevel(void)
{
	return m_nMaintenanceLevel;
}

void CCat::setMaintenanceLevel(int nMaintenanceLevel)
{
	m_nMaintenanceLevel = nMaintenanceLevel;
}

CCat::~CCat()
{
	if(m_strBreed !=NULL)
		delete [] m_strBreed;
}
