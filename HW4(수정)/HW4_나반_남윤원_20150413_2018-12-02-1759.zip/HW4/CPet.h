#ifndef CPet_H
#define CPet_H
#include <iostream>
#include <Windows.h>
#include <mmsystem.h>
#include <opencv2/core/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui/highgui.hpp>
#pragma comment(lib, "winmm.lib")

using namespace cv;
using namespace std;

// CPet Ŭ������ ����ϴ�. �θ� Ŭ�����Դϴ�.
class CPet
{
public:
	CPet();
	CPet(const char *strName, const char *strBreed);
	CPet(const CPet &ob);
	char *getName(void) const;
	void setName(const char *na);
	const CPet& operator =(const CPet &rightSide);
	virtual void ShowHappiness(char* strName) = 0;
	virtual void ShowHappyFace(char* strName) = 0;
	virtual void MakeSound() = 0;
	virtual void print(void) = 0;
	virtual ~CPet();

protected:
	char *m_strName;
	char *m_strBreed;
};

#endif
  