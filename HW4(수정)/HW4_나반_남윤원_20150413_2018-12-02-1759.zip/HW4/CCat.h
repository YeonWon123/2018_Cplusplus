#ifndef CCat_H
#define CCat_H

#include <iostream>
#include "CPet.h"

using namespace std;

// CCat class�� ����ϴ�. �ڽ� Ŭ�����Դϴ�.
class CCat: public CPet
{
public:
	CCat();
	CCat(const char *strName, const char *strBreed, int nMaintenanceLevel);
	CCat(const CCat& ob);
	~CCat();

	char *getBreed(void) const;
	void setBreed(const char *br);
	void ShowHappiness(char* strName);
	void ShowHappyFace(char* strName);
	void MakeSound();
	void print(void);
	const CCat& operator=(const CCat& rightSide);
	int getMaintenanceLevel(void);
	void setMaintenanceLevel(int nMaintenanceLevel);

private:
	int m_nMaintenanceLevel;
};

#endif