#ifndef CDog_H
#define CDog_H

#include <iostream>
#include "CPet.h"

using namespace std;

// CDog class�� ����ϴ�. �ڽ� Ŭ�����Դϴ�.
class CDog: public CPet
{
public:
	CDog();
	CDog(const char *strName, const char *strBreed, int nActive);
	CDog(const CDog &ob);
	~CDog();
	char *getBreed(void) const;
	void setBreed(const char *br);
	void MakeSound(void);
	void ShowHappyFace(char* strName);
	void ShowHappiness(char* strName);
	void print(void);
	const CDog& operator =(const CDog &rightSide);
	int getActive(void);
	void setActive(int nActive);

private:
	int m_nActive;
};

#endif